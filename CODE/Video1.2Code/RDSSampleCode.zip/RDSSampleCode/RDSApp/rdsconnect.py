import psycopg2
from bottle import route, run, debug, template, request, static_file, error

# only needed when you run Bottle on mod_wsgi
from bottle import default_app

# REPLACE THE BELOW VALUES WITH YOUR RDS DB CONFIGS
DBNAME = 'colibridb'
USER = 'colibriuser'
PASSWORD = 'colibripw'
HOST = ''
PORT = 5432


@route('/')
def connect():

    try:
        kwargs = {'dbname': DBNAME, 'user': USER, 'host': HOST, 'password': PASSWORD, 'port': PORT}
        conn = psycopg2.connect(connect_timeout=3, **kwargs)
        message = 'Successfully connected to RDS with the creds: {}'.format(kwargs)
        conn.close()
    except Exception:
        message = 'Unable to connect to RDS'

    output = template('connect', message=message)
    return output


debug(True)
run(host = '0.0.0.0', port=80, reloader=True)
# remember to remove reloader=True and debug(True) when you move your
# application from development to a productive environment
