#!/bin/bash
apt-get update -y
apt-get install -y python-pip python-dev libpq-dev postgresql postgresql-contrib
pip install bottle psycopg2
